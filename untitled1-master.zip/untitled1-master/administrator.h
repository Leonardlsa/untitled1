//
// Created by Leonard on 2022/11/23.
//

#ifndef BIGPROJECT_ADMINISTRATOR_H
#define BIGPROJECT_ADMINISTRATOR_H

void administrator_homepage() ;


#endif //BIGPROJECT_ADMINISTRATOR_H
