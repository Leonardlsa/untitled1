//
// Created by 23221 on 2022/11/24.
//

#ifndef UNTITLED1_SELLER_H
#define UNTITLED1_SELLER_H
#include "basic_function.h"

void seller_homePage(User self);

#endif //UNTITLED1_SELLER_H
