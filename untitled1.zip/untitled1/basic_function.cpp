#include "basic_function.h"
#include "basic_struct.h"
#include "file_dealer.h"

using std::string;
using std::cout;

/*��ӡ��Ŀ
 * s�����ӡ��Ŀ
 * num����Ŀ����
 */
inline void clear() {
    system("cls");
}

void print(string *s, int num) {
    string out;
    for (int i = 0; i < num; ++i) {
        out += (char) (i + 49);
        out += ".";
        out += s[i];
        out += '\t';
    }
    int len = (int) out.length();

    string bar2((int) (len * 1.35), '=');
    cout << bar2 << std::endl
         << out << std::endl
         << bar2 << std::endl << std::endl;
}

void print_message(const string s) {
    string bar2((int) (s.length() * 1.35), '*');
    cout << endl
         << bar2 << std::endl
         << s << std::endl
         << bar2 << std::endl << std::endl;
}

string input_password(string hint) {

    int cursor = 0;
    char temp;
    char pass[20];
    input_pass_loop:
    cout << hint << std::flush;
    cursor = 0;
    while ((temp = getch()) != '\r' && cursor <= 19) {
        if (temp == '\b' && cursor > 0) {
            printf("\b \b");
            cursor--;
        } else {
            if ((temp >= 48 && temp <= 57) || (temp >= 65 && temp <= 90) || (temp >= 97 && temp <= 122)) {
                pass[cursor++] = temp;
                cout << '*';
            } else if (temp != '\b') {
                print_message("���������ĸ���ֹ��ɣ�");
                goto input_pass_loop;
            }
        }
    }
    if (cursor >= 20) {
        print_message("���볤�Ȳ�����20��");
        goto input_pass_loop;
    }
    pass[cursor] = '\0';
    return string(pass);

}

string number2string00x(int i) {//Ĭ��i����3λ
    if (i < 10)return "00" + std::to_string(i);
    else if (i < 100)return "0" + std::to_string(i);
    else return std::to_string(i);
}
int string00x2number(string id){
    return 100*(id[0]-48)+10*(id[1]-48)+(id[2]-48);
}
string current_time() {
    string s;
    time_t now = time(NULL);
    tm *tm_t = localtime(&now);
    s = std::to_string(tm_t->tm_year + 1900) + '-' + std::to_string(tm_t->tm_mon + 1) + '-' +
        std::to_string(tm_t->tm_mday);
    return s;
}

/*
 * prefixչʾ��Ʒ��ͷ
 * suffixչʾ��Ʒ��β
 */
void show_goods_prefix() {
    cout << goods_bar << endl
         << std::setw(goodShow[0]) << std::left << "��ƷID"
         << std::setw(goodShow[1]) << std::left << "����"
         << std::setw(goodShow[2]) << std::left << "�۸�"
         << std::setw(goodShow[3]) << std::left << "�ϼ�ʱ��"
         << std::setw(goodShow[4]) << std::left << "����ID"
         << std::setw(goodShow[5]) << std::left << "����"
         << std::setw(goodShow[6]) << std::left << "��Ʒ״̬" << endl;
}

void show_goods_suffix() {
    cout << goods_bar << endl;
}

void show_order_prefix() {
    cout << order_bar << endl
         << std::setw(orderShow[0]) << std::left << "����ID"
         << std::setw(orderShow[1]) << std::left << "��ƷID"
         << std::setw(orderShow[2]) << std::left << "���׵���"
         << std::setw(orderShow[3]) << std::left << "����"
         << std::setw(orderShow[4]) << std::left << "����ʱ��"
         << std::setw(orderShow[5]) << std::left << "����ID"
         << std::setw(orderShow[6]) << std::left << "���ID" << endl;
}

void show_order_suffix() {
    cout << order_bar << endl;
}

void show_user_prefix() {
    cout << user_bar << endl
         << std::setw(userShow[0]) << std::left << "�û�ID"
         << std::setw(userShow[1]) << std::left << "�û���"
         << std::setw(userShow[2]) << std::left << "��ϵ��ʽ"
         << std::setw(userShow[3]) << std::left << "��ַ"
         << std::setw(userShow[4]) << std::left << "Ǯ�����"
         << std::setw(userShow[5]) << std::left << "�û�״̬" << endl;
}

void show_user_suffix() {
    cout << user_bar << endl;
}

/*
 * ��"*"�������룬���λ���
 * password��������
 * cursor�����ָ
 * judge��������Դ�
 */
bool CheckPassWord(string password) {
    bool judge = false;
    int cursor;
    int remaintimes = 1;
    string s;
    char temp;
    char truepassword[50];
    while (remaintimes <= 3) {
        cursor = 0;
        while ((temp = getch()) != '\r') {
            if (temp == '\b' && cursor > 0) {
                printf("\b \b");
                cursor--;
            } else {
                truepassword[cursor++] = temp;
                cout << '*';
            }
        }
        truepassword[cursor] = '\0';
        cout << endl;
        if (password.compare(truepassword) != 0) {
            if (remaintimes == 3)
                cout << "��������˳���" << endl << endl;
            else
                cout << "�������ʣ��" << (3 - remaintimes) << "�λ��᣺";
            remaintimes++;
        } else {
            judge = true;
            return judge;
        }
    }
    if (remaintimes == 4)
        return judge;
    return judge;
}

void err_input(string error_message) {
    cout << "���벻��Ҫ������������" << endl;
    cin.clear();
    cin.ignore(INT_MAX, '\n');
    getch();
    clear();
}

void COLOR_PRINT(const char *s, int color) {
    HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(handle, FOREGROUND_INTENSITY | color);
    printf(s);
    SetConsoleTextAttribute(handle, FOREGROUND_INTENSITY | 7);
}

User find_user_by_username(string usrnm, int &user_num) {
    User *userlist = read_user(user_num);
    for (int i = 0; i < user_num; ++i) {
        if (strstr(userlist[i].Username.c_str(), usrnm.c_str()) != NULL) {
            User temp=userlist[i];
            delete[] userlist;
            return temp;
        }
    }
    delete[] userlist;
    return USER_NUL;
}
Goods find_good_by_goodid(string gid){
    int i;
    Goods* goodlist= read_goods(i);
    if (i>= string00x2number(gid.substr(1,4)))return goodlist[string00x2number(gid.substr(1,4))-1];
    else return Goods_NUL;
}