//
// Created by 23221 on 2022/11/23.
//

#ifndef BIGPROJECT_START_H
#define BIGPROJECT_START_H

#define NUM_LOGIN_CHOICE 4


void login_surface();

#endif //BIGPROJECT_START_H
