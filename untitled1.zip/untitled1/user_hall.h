//
// Created by Leonard on 2022/11/24.
//

#ifndef UNTITLED1_USER_HALL_H
#define UNTITLED1_USER_HALL_H
#include "basic_struct.h"
void user_homePage(User);
#endif //UNTITLED1_USER_HALL_H
