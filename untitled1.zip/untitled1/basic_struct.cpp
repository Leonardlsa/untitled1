//
// Created by 23221 on 2022/11/23.
//

#include "basic_function.h"
#include "basic_struct.h"
#include "crypto.h"

void Goods::adminseller_show() {
    std::cout << std::setw(goodShow[0]) << std::left << goodID
              << std::setw(goodShow[1]) << std::left << name
              << std::setw(goodShow[2]) << std::left <<setiosflags (std::ios::fixed)<<std::setprecision(1)<<price
              << std::setw(goodShow[3]) << std::left << launch_time
              << std::setw(goodShow[4]) << std::left << sellerID
              << std::setw(goodShow[5]) << std::left << amount;
    if (status == 1) std::cout << std::setw(goodShow[6]) << std::left << "������";
    else if (status == 0)std::cout << std::setw(goodShow[6]) << std::left << "���¼�";
    else std::cout << std::setw(goodShow[6]) << std::left << "������";
    cout << endl;
}

void Order::show() {
    std::cout << std::setw(orderShow[0]) << std::left << orderID
              << std::setw(orderShow[1]) << std::left << goodID
              << std::setw(orderShow[2]) << std::left <<setiosflags (std::ios::fixed)<<std::setprecision(1)<< transaction_price
              << std::setw(orderShow[3]) << std::left << amount
              << std::setw(orderShow[4]) << std::left << transaction_time
              << std::setw(orderShow[5]) << std::left << sellerID
              << std::setw(orderShow[6]) << std::left << buyerID << endl;
}

void User::show() {
    std::cout << std::setw(userShow[0]) << std::left << UID
              << std::setw(userShow[1]) << std::left << Username
              << std::setw(userShow[2]) << std::left << tel
              << std::setw(userShow[3]) << std::left << address
              << std::setw(userShow[4]) << std::left <<setiosflags (std::ios::fixed)<<std::setprecision(1)<< balance
              << std::setw(userShow[5]) << std::left << (status?"����":"���") << endl;
}


TOP_SECRET::TOP_SECRET(string uid,string pass){
    UID=uid;
    encryptedpass= base64_encode(pass.c_str(),pass.length());
}
