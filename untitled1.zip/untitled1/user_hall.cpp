//
// Created by Leonard on 2022/11/24.
//

#include "user_hall.h"
void user_homePage(User self) {

}