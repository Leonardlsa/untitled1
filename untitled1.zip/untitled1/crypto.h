//
// Created by Leonard on 2022/11/24.
//

#ifndef UNTITLED1_CRYPTO_H
#define UNTITLED1_CRYPTO_H

#include <string>

std::string base64_encode(const char *bytes_to_encode, size_t in_len, bool url = false);

static const char* base64_chars[2] = {
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz"
        "0123456789"
        "+/",

        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz"
        "0123456789"
        "-_"};

#endif //UNTITLED1_CRYPTO_H
