//
// Created by Leonard on 2022/11/23.
//

#ifndef BIGPROJECT_FILE_DEALER_H
#define BIGPROJECT_FILE_DEALER_H


const int MAX_GOODS = 100;
const int MAX_ORDER = 200;
const int MAX_USER = 100;

Goods* read_goods(int &item_number);
bool write_goods(Goods *list, const int item_number);
bool append_goods(Goods goods);
Order *read_order(int &item_number) ;
bool write_order(Order *list, const int item_number);
User *read_user(int &item_number) ;
bool write_user(User *list, const int item_number);
bool append_user(User u);
bool check_password(string uid, string pass);
bool write_register(TOP_SECRET t);

#endif //BIGPROJECT_FILE_DEALER_H
