//
// Created by Leonard on 2022/11/23.
//

#ifndef BIGPROJECT_BASIC_STRUCT_H
#define BIGPROJECT_BASIC_STRUCT_H

#include <string>

using std::string;
const static char* GOODS_PATH=".\\data\\goods.txt";
const static char* ORDER_PATH=".\\data\\order.txt";
const static char* USER_PATH=".\\data\\user.txt";
const int goodShow[]={9,18,8,15,9,8,12};
const int orderShow[]={9,9,9,8,18,9,9};
const int userShow[]={9,20,15,20,12,8};
static std::string goods_bar(75, '*');
static std::string order_bar(75, '*');
static std::string user_bar(90, '*');
struct Goods{
    string goodID;
    string name;
    float price;
    string launch_time;
    string sellerID;
    int amount;
    int status;//0�������¼ܣ�1����������,2����������
    void show();
};

struct Order{
    string orderID;
    string goodID;
    float transaction_price;
    int amount;
    string transaction_time;
    string sellerID;
    string buyerID;
    void show();
};

struct User{
    string UID;
    string Username;
    string tel;
    string address;
    float balance;
    bool status;//0�����1����
    void show();
};
#endif //BIGPROJECT_BASIC_STRUCT_H
