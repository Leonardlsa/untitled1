//
// Created by Leonard on 2022/11/23.
//

#ifndef BIGPROJECT_BASIC_STRUCT_H
#define BIGPROJECT_BASIC_STRUCT_H

#include <string>

using std::string;
const static char* GOODS_PATH=".\\data\\goods.txt";
const static char* ORDER_PATH=".\\data\\order.txt";
const static char* USER_PATH=".\\data\\user.txt";
const static char* SECRET_PATH=".\\data\\.secret.txt";
const int goodShow[]={9,40,12,15,9,8,12};
const int orderShow[]={9,9,9,8,12,9,9};
const int userShow[]={9,18,15,55,12,8};
static std::string goods_bar(110, '*');
static std::string order_bar(70, '*');
static std::string user_bar(130, '*');
struct Goods{
    string goodID;
    string name;
    double price;
    string launch_time;
    string sellerID;
    int amount;
    int status;//0�������¼ܣ�1����������,2����������
    string description;
    void adminseller_show();
};
const Goods Goods_NUL={"-1"};

struct Order{
    string orderID;
    string goodID;
    double transaction_price;
    int amount;
    string transaction_time;
    string sellerID;
    string buyerID;
    void show();
};

struct User{
    string UID;
    string Username;
    string tel;
    string address;
    double balance;
    bool status;//0�����1����
    void show();
};
const User USER_NUL={"-1"};
struct TOP_SECRET{
    string UID;
    string encryptedpass;
    TOP_SECRET(string uid,string pass);
};
#endif //BIGPROJECT_BASIC_STRUCT_H
